Student System
==============

The basic student system used for demonstration purposes.